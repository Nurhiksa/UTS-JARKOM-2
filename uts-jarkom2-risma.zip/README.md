# UTS Jaringan Komputer 2 - Risma Nurhiksa

## Layanan yang Dikembangkan:
- DHCP Server
- DNS Server
- Firewall (iptables)

## Struktur File:
- /etc/dhcp/dhcpd.conf
- /etc/bind/named.conf.local
- /etc/bind/db.server.local
- /etc/bind/db.192
- firewall.sh (Script konfigurasi iptables)

## Dokumentasi Video:
Tautan YouTube: [klik di sini](https://www.youtube.com/watch?v=video_dummy)